#include <stdio.h>
#include <stdlib.h>
#include "User_defined.h"
//
int main(void)
{
	User_defined_print();
	system("PAUSE");
	return 0;
}