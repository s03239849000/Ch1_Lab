#include <stdio.h>
#include <stdlib.h>

int User_defined_print()
{
	printf("Welcome to C \n");
	return 0;
}